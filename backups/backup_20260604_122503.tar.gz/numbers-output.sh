#!/bin/bash
# Create a script that outputs the numbers 1 to 10, one number per line
for (( i=0; i<=10; i++))
do 
	echo "$i"
done
